import { Component, type ErrorInfo, type ReactNode } from 'react';
export default class AiroErrorBoundary extends Component<{ children: ReactNode; captureGlobalErrors?: boolean }, { error?: Error }> {
  state: { error?: Error } = {};
  static getDerivedStateFromError(error: Error) { return { error }; }
  componentDidCatch(error: Error, info: ErrorInfo) { console.error('Application error', error, info); }
  render() {
    if (!this.state.error) return this.props.children;
    return <main className="min-h-screen grid place-items-center p-8"><div className="max-w-xl"><h1 className="text-2xl font-bold">Something went wrong.</h1><pre className="mt-4 overflow-auto rounded-lg bg-secondary p-4 text-xs">{this.state.error.message}</pre></div></main>;
  }
}
