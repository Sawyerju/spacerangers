import { Component, type ErrorInfo, type ReactNode } from 'react';
export default class CookieBannerErrorBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  componentDidCatch(error: Error, info: ErrorInfo) { console.warn('Cookie banner error', error, info); }
  render() { return this.state.failed ? null : this.props.children; }
}
