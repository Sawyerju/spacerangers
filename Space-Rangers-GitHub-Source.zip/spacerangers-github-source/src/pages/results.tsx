import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { results } from 'virtual:content';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.1 } } };

export default function ResultsPage() {
  const siteUrl = 'https://gccazascendspacerangers.com';
  return (
    <>
      <Helmet>
        <title>Results — Space Rangers NASA ASCEND GCC</title>
        <meta name="description" content="Flight data, graphs, expected vs actual results, and lessons learned from our NASA ASCEND high-altitude balloon mission." />
        <link rel="canonical" href={`${siteUrl}/results`} />
        <meta property="og:title" content="Results — Space Rangers" />
        <meta property="og:description" content="Data collected, analysis, and lessons learned from our high-altitude balloon mission." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`${siteUrl}/results`} />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main>
        {/* Hero */}
        <section className="relative pt-32 pb-20" style={{ background: 'hsl(var(--surface-navy))' }}>
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" animate="visible" variants={stagger}>
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-accent mb-3">{results.hero.eyebrow}</motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-accent mb-5" />
              <motion.h1 variants={fadeUp} className="text-4xl md:text-6xl font-bold text-white mb-5 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
                {results.hero.headline}
              </motion.h1>
              <motion.p variants={fadeUp} className="text-lg text-white/70 max-w-2xl leading-relaxed">{results.hero.subheadline}</motion.p>
            </motion.div>
          </div>
        </section>

        {/* Flight status banner */}
        <section className="py-xl bg-secondary border-b border-border">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-6 rounded-xl border border-border bg-background">
              <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center shrink-0">
                <svg className="w-5 h-5 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <p className="font-semibold text-foreground">{results.status.heading}</p>
                <p className="text-sm text-muted-foreground mt-0.5">{results.status.body}</p>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Data sections */}
        <section className="py-xxl bg-background">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-40px' }} variants={stagger} className="flex flex-col gap-16">
              {results.data_sections.map((sec, i) => {
                const isEven = i % 2 === 0;
                return (
                  <motion.div key={sec.id} variants={fadeUp} className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
                    <div className={isEven ? '' : 'lg:order-2'}>
                      <div className="flex items-center gap-3 mb-4">
                        <span className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-white text-xs font-bold" style={{ fontFamily: 'var(--font-heading)' }}>
                          {String(i + 1).padStart(2, '0')}
                        </span>
                      </div>
                      <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4" style={{ fontFamily: 'var(--font-heading)' }}>{sec.title}</h2>
                      <p className="text-muted-foreground leading-relaxed">{sec.body}</p>
                    </div>
                    <div className={isEven ? '' : 'lg:order-1'}>
                      <div className="w-full rounded-xl border-2 border-dashed border-border bg-secondary flex flex-col items-center justify-center gap-3 py-14 px-6 text-center min-h-[200px]">
                        <svg className="w-10 h-10 text-muted-foreground/40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                        </svg>
                        <p className="text-sm text-muted-foreground">{sec.image_caption}</p>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>
        </section>

        {/* Lessons Learned */}
        <section className="py-xxl" style={{ background: 'hsl(var(--surface-navy))' }}>
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }} variants={stagger}>
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-accent mb-3">Reflection</motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-accent mb-5" />
              <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold text-white mb-4" style={{ fontFamily: 'var(--font-heading)' }}>
                {results.lessons.heading}
              </motion.h2>
              <motion.p variants={fadeUp} className="text-white/60 max-w-2xl mb-12">{results.lessons.intro}</motion.p>

              <motion.div variants={stagger} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mb-16">
                {results.lessons.items.map((item) => (
                  <motion.div key={item.id} variants={fadeUp} className="rounded-xl p-5 border" style={{ background: 'hsl(var(--surface-navy)/0.6)', borderColor: 'hsl(var(--navy-border))' }}>
                    <p className="text-xs font-semibold tracking-widest uppercase text-accent mb-3">{item.category}</p>
                    <p className="text-sm text-white/70 leading-relaxed">{item.body}</p>
                  </motion.div>
                ))}
              </motion.div>

              {/* Closing quote */}
              <motion.div variants={fadeUp} className="text-center max-w-3xl mx-auto">
                <div className="w-12 h-0.5 bg-accent mx-auto mb-6" />
                <p className="text-xl md:text-2xl font-bold text-white italic leading-relaxed" style={{ fontFamily: 'var(--font-heading)' }}>
                  "{results.lessons.closing}"
                </p>
                <p className="text-sm text-white/50 mt-4">— Space Rangers, GCC NASA ASCEND</p>
              </motion.div>
            </motion.div>
          </div>
        </section>
      </main>
    </>
  );
}
