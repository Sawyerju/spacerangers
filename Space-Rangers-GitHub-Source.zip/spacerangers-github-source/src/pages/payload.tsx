import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { payload } from 'virtual:content';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.1 } } };

const categoryColors: Record<string, string> = {
  Sensors: 'bg-primary/10 text-primary',
  Microcontroller: 'bg-accent/10 text-accent',
  'Data Storage': 'bg-muted text-muted-foreground',
  Power: 'bg-yellow-100 text-yellow-800',
  Structure: 'bg-green-100 text-green-800',
};

export default function PayloadPage() {
  const siteUrl = 'https://gccazascendspacerangers.com';
  return (
    <>
      <Helmet>
        <title>Our Payload — Space Rangers NASA ASCEND GCC</title>
        <meta name="description" content="The science and engineering behind our high-altitude payload — mission objective, sensors, components, and expected results." />
        <link rel="canonical" href={`${siteUrl}/payload`} />
        <meta property="og:title" content="Our Payload — Space Rangers" />
        <meta property="og:description" content="Mission objective, sensors, components, and expected results for our NASA ASCEND payload." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`${siteUrl}/payload`} />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main>
        {/* Hero */}
        <section className="relative pt-32 pb-20 overflow-hidden" style={{ background: 'hsl(var(--surface-navy))' }}>
          <div className="absolute inset-0 pointer-events-none">
            <img src="https://gccazascendspacerangers.com/airo-assets/images/pages/payload/hero" alt="" aria-hidden="true" className="w-full h-full object-cover opacity-20" loading="eager" />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" animate="visible" variants={stagger}>
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-accent mb-3">{payload.hero.eyebrow}</motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-accent mb-5" />
              <motion.h1 variants={fadeUp} className="text-4xl md:text-6xl font-bold text-white mb-5 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
                {payload.hero.headline}
              </motion.h1>
              <motion.p variants={fadeUp} className="text-lg text-white/70 max-w-2xl leading-relaxed">{payload.hero.subheadline}</motion.p>
            </motion.div>
          </div>
        </section>

        {/* Mission Objective + Scientific Question */}
        <section className="py-xxl bg-background">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }} variants={stagger} className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div>
                <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Mission</motion.p>
                <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
                <motion.h2 variants={fadeUp} className="text-3xl font-bold mb-5" style={{ fontFamily: 'var(--font-heading)' }}>{payload.mission.heading}</motion.h2>
                <motion.p variants={fadeUp} className="text-muted-foreground leading-relaxed mb-6">{payload.mission.body}</motion.p>
                <motion.div variants={fadeUp} className="p-5 rounded-xl border-l-4 border-accent bg-secondary">
                  <p className="text-xs font-semibold tracking-widest uppercase text-accent mb-2">Scientific Question</p>
                  <p className="text-foreground leading-relaxed italic">"{payload.mission.question}"</p>
                </motion.div>
              </div>
              <motion.div variants={stagger}>
                <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Experiment</motion.p>
                <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
                <motion.h2 variants={fadeUp} className="text-3xl font-bold mb-5" style={{ fontFamily: 'var(--font-heading)' }}>{payload.experiment.heading}</motion.h2>
                <motion.p variants={fadeUp} className="text-muted-foreground leading-relaxed mb-6">{payload.experiment.body}</motion.p>
                <motion.div variants={fadeUp} className="p-5 rounded-xl border border-border bg-secondary">
                  <p className="text-xs font-semibold tracking-widest uppercase text-primary mb-2">Hypothesis</p>
                  <p className="text-muted-foreground leading-relaxed text-sm">{payload.experiment.hypothesis}</p>
                </motion.div>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* Payload Overview + image placeholder */}
        <section className="py-xxl bg-secondary">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }} variants={stagger} className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Hardware</motion.p>
                <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
                <motion.h2 variants={fadeUp} className="text-3xl font-bold mb-5" style={{ fontFamily: 'var(--font-heading)' }}>{payload.overview.heading}</motion.h2>
                <motion.p variants={fadeUp} className="text-muted-foreground leading-relaxed">{payload.overview.body}</motion.p>
              </div>
              <motion.div variants={fadeUp} className="w-full rounded-xl border-2 border-dashed border-border bg-background flex flex-col items-center justify-center gap-3 py-14 px-6 text-center">
                <svg className="w-10 h-10 text-muted-foreground/40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <p className="text-sm text-muted-foreground">{payload.overview.image_caption}</p>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* Components */}
        <section className="py-xxl bg-background">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }} variants={stagger} className="mb-12">
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Components</motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
              <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold" style={{ fontFamily: 'var(--font-heading)' }}>Sensors &amp; Components</motion.h2>
            </motion.div>
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-60px' }} variants={stagger} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {payload.components.map((comp) => (
                <motion.div key={comp.id} variants={fadeUp} className="rounded-xl border border-border bg-background p-5">
                  <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full mb-3 inline-block ${categoryColors[comp.category] ?? 'bg-muted text-muted-foreground'}`}>
                    {comp.category}
                  </span>
                  <h3 className="text-base font-bold text-foreground mb-2" style={{ fontFamily: 'var(--font-heading)' }}>{comp.name}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{comp.description}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* Data + Expected Results */}
        <section className="py-xxl bg-secondary">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }} variants={stagger} className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
              <div>
                <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Data</motion.p>
                <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
                <motion.h2 variants={fadeUp} className="text-3xl font-bold mb-6" style={{ fontFamily: 'var(--font-heading)' }}>{payload.data.heading}</motion.h2>
                <motion.div variants={stagger} className="flex flex-col gap-3">
                  {payload.data.items.map((item) => (
                    <motion.div key={item.id} variants={fadeUp} className="flex items-start gap-3 p-4 rounded-lg bg-background border border-border">
                      <span className="w-2 h-2 rounded-full bg-primary mt-1.5 shrink-0" />
                      <div>
                        <span className="text-sm font-semibold text-foreground">{item.label}</span>
                        <span className="text-sm text-muted-foreground"> — {item.detail}</span>
                      </div>
                    </motion.div>
                  ))}
                </motion.div>
              </div>
              <motion.div variants={stagger}>
                <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Predictions</motion.p>
                <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
                <motion.h2 variants={fadeUp} className="text-3xl font-bold mb-5" style={{ fontFamily: 'var(--font-heading)' }}>{payload.expected.heading}</motion.h2>
                <motion.p variants={fadeUp} className="text-muted-foreground leading-relaxed">{payload.expected.body}</motion.p>
              </motion.div>
            </motion.div>
          </div>
        </section>
      </main>
    </>
  );
}
