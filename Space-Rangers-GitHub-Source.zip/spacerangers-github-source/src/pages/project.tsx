import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { CheckCircle2, Circle, Loader2 } from 'lucide-react';
import { project } from 'virtual:content';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.1 } } };

const statusConfig: Record<string, { icon: typeof CheckCircle2; label: string; color: string }> = {
  complete: { icon: CheckCircle2, label: 'Complete', color: 'text-primary' },
  active: { icon: Loader2, label: 'In Progress', color: 'text-accent' },
  upcoming: { icon: Circle, label: 'Upcoming', color: 'text-muted-foreground' },
};

export default function ProjectPage() {
  const siteUrl = 'https://gccazascendspacerangers.com';
  return (
    <>
      <Helmet>
        <title>Our Project — Space Rangers NASA ASCEND GCC</title>
        <meta name="description" content="Full engineering documentation for the Space Rangers payload project — research, design, construction, testing, flight, and results." />
        <link rel="canonical" href={`${siteUrl}/project`} />
        <meta property="og:title" content="Our Project — Space Rangers" />
        <meta property="og:description" content="From design to flight: documenting our high-altitude payload engineering process." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`${siteUrl}/project`} />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main>
        {/* Hero */}
        <section className="relative pt-32 pb-20 overflow-hidden" style={{ background: 'hsl(var(--surface-navy))' }}>
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <img
              src="https://gccazascendspacerangers.com/airo-assets/images/pages/project/hero"
              alt=""
              aria-hidden="true"
              className="w-full h-full object-cover opacity-20"
              loading="eager"
            />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" animate="visible" variants={stagger}>
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-accent mb-3">
                {project.hero.eyebrow}
              </motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-accent mb-5" />
              <motion.h1
                variants={fadeUp}
                className="text-4xl md:text-6xl font-bold text-white mb-5 leading-tight"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {project.hero.headline}
              </motion.h1>
              <motion.p variants={fadeUp} className="text-lg text-white/70 max-w-2xl leading-relaxed">
                {project.hero.subheadline}
              </motion.p>
            </motion.div>
          </div>
        </section>

        {/* Overview */}
        <section className="py-xxl bg-background">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div
              initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }}
              variants={stagger}
              className="grid grid-cols-1 lg:grid-cols-3 gap-12"
            >
              <div className="lg:col-span-2">
                <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Project Overview</motion.p>
                <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
                <motion.h2 variants={fadeUp} className="text-3xl font-bold mb-5" style={{ fontFamily: 'var(--font-heading)' }}>
                  {project.overview.heading}
                </motion.h2>
                <motion.p variants={fadeUp} className="text-muted-foreground leading-relaxed mb-6">
                  {project.overview.body}
                </motion.p>
                <motion.div variants={fadeUp} className="p-5 rounded-xl border-l-4 border-primary bg-secondary">
                  <p className="text-xs font-semibold tracking-widest uppercase text-primary mb-2">Scientific Objective</p>
                  <p className="text-foreground leading-relaxed">{project.overview.objective}</p>
                </motion.div>
              </div>

              {/* Specs */}
              <motion.div variants={fadeUp}>
                <p className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">{project.specs.heading}</p>
                <div className="w-8 h-0.5 bg-primary mb-5" />
                <div className="rounded-xl border border-border overflow-hidden">
                  {project.specs.items.map((spec, i) => (
                    <div
                      key={spec.id}
                      className={`flex justify-between items-center px-4 py-3 ${i !== project.specs.items.length - 1 ? 'border-b border-border' : ''}`}
                    >
                      <span className="text-sm text-muted-foreground">{spec.label}</span>
                      <span className="text-sm font-semibold text-foreground">{spec.value}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* Balloon image */}
        <section className="bg-secondary">
          <div className="max-w-7xl mx-auto px-6 lg:px-8 py-8">
            <motion.div
              initial="hidden" whileInView="visible" viewport={{ once: true }}
              variants={fadeUp}
              className="rounded-2xl overflow-hidden h-64 md:h-80"
            >
              <img
                src="https://gccazascendspacerangers.com/airo-assets/images/pages/project/balloon-launch"
                alt="Weather balloon launch preparation"
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </motion.div>
          </div>
        </section>

        {/* Engineering Phases */}
        <section className="py-xxl bg-secondary">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div
              initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }}
              variants={stagger}
              className="mb-12"
            >
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Engineering Process</motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
              <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold" style={{ fontFamily: 'var(--font-heading)' }}>
                Phase-by-Phase Documentation
              </motion.h2>
            </motion.div>

            <div className="flex flex-col gap-6">
              {project.phases.map((phase) => {
                const cfg = statusConfig[phase.status] ?? statusConfig.upcoming;
                const Icon = cfg.icon;
                const isActive = phase.status === 'active';
                return (
                  <motion.div
                    key={phase.id}
                    initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-40px' }}
                    variants={fadeUp}
                    className={`rounded-xl border p-6 md:p-8 ${isActive ? 'border-primary bg-background shadow-md' : 'border-border bg-background'}`}
                  >
                    <div className="flex flex-col md:flex-row md:items-start gap-6">
                      {/* Phase number */}
                      <div className="shrink-0">
                        <div className={`w-14 h-14 rounded-xl flex items-center justify-center font-bold text-lg ${isActive ? 'bg-primary text-white' : 'bg-secondary text-muted-foreground'}`}
                          style={{ fontFamily: 'var(--font-heading)' }}>
                          {phase.number}
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-3 mb-3">
                          <h3 className="text-xl font-bold text-foreground" style={{ fontFamily: 'var(--font-heading)' }}>{phase.title}</h3>
                          <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${isActive ? 'bg-accent/10 text-accent' : phase.status === 'complete' ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                            <Icon className={`w-3 h-3 ${phase.status === 'active' ? 'animate-spin' : ''}`} />
                            <span>{cfg.label}</span>
                          </span>
                        </div>
                        <p className="text-muted-foreground mb-4 leading-relaxed">{phase.details}</p>
                        <div>
                          <p className="text-xs font-semibold tracking-widest uppercase text-primary mb-2">Deliverables</p>
                          <ul className="flex flex-col gap-1">
                            {phase.deliverables.map((d, i) => (
                              <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                                <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${phase.status === 'complete' ? 'bg-primary' : phase.status === 'active' ? 'bg-accent' : 'bg-border'}`} />
                                <span>{d}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
