import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { CheckCircle2, Circle, Loader2 } from 'lucide-react';
import { progress } from 'virtual:content';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.1 } } };

const dotClass: Record<string, string> = {
  complete: 'bg-primary border-primary',
  active: 'bg-accent border-accent',
  upcoming: 'bg-background border-border',
};

const badgeClass: Record<string, string> = {
  complete: 'bg-primary/10 text-primary',
  active: 'bg-accent/10 text-accent',
  upcoming: 'bg-muted text-muted-foreground',
};

function statusLabel(s: string) {
  if (s === 'complete') return 'Complete';
  if (s === 'active') return 'In Progress';
  return 'Upcoming';
}

export default function ProgressPage() {
  const siteUrl = 'https://gccazascendspacerangers.com';
  return (
    <>
      <Helmet>
        <title>Progress Log — Space Rangers NASA ASCEND GCC</title>
        <meta name="description" content="Week-by-week progress log for the Space Rangers NASA ASCEND project — what we built, what we learned, and what comes next." />
        <link rel="canonical" href={`${siteUrl}/progress`} />
        <meta property="og:title" content="Progress Log — Space Rangers" />
        <meta property="og:description" content="A semester-long record of our engineering work from kickoff to flight." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`${siteUrl}/progress`} />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main>
        {/* Hero */}
        <section className="relative pt-32 pb-20" style={{ background: 'hsl(var(--surface-navy))' }}>
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" animate="visible" variants={stagger}>
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-accent mb-3">{progress.hero.eyebrow}</motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-accent mb-5" />
              <motion.h1 variants={fadeUp} className="text-4xl md:text-6xl font-bold text-white mb-5 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
                {progress.hero.headline}
              </motion.h1>
              <motion.p variants={fadeUp} className="text-lg text-white/70 max-w-2xl leading-relaxed">{progress.hero.subheadline}</motion.p>
            </motion.div>
          </div>
        </section>

        {/* Timeline */}
        <section className="py-xxl bg-background">
          <div className="max-w-4xl mx-auto px-6 lg:px-8">
            <div className="relative">
              {/* Vertical connector line */}
              <div className="absolute left-5 top-5 bottom-5 w-0.5 bg-border hidden md:block" />

              <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-40px' }} variants={stagger} className="flex flex-col gap-8">
                {progress.entries.map((entry) => (
                  <motion.div key={entry.id} variants={fadeUp} className="flex flex-col md:flex-row gap-4 md:gap-8">
                    {/* Dot */}
                    <div className="hidden md:flex flex-col items-center shrink-0 w-10 pt-1">
                      <div className={`w-10 h-10 rounded-full border-2 flex items-center justify-center z-10 ${dotClass[entry.status]}`}>
                        {entry.status === 'complete' && <CheckCircle2 className="w-5 h-5 text-primary" />}
                        {entry.status === 'active' && <Loader2 className="w-5 h-5 text-accent animate-spin" />}
                        {entry.status === 'upcoming' && <Circle className="w-5 h-5 text-muted-foreground" />}
                      </div>
                    </div>

                    {/* Card */}
                    <div className={`flex-1 rounded-xl border p-6 ${entry.status === 'active' ? 'border-accent/40 bg-accent/5' : 'border-border bg-background'}`}>
                      {/* Header */}
                      <div className="flex flex-wrap items-center gap-3 mb-4">
                        <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${badgeClass[entry.status]}`}>{statusLabel(entry.status)}</span>
                        <span className="text-xs font-bold text-primary">{entry.week}</span>
                        <time dateTime={entry.date} className="text-xs text-muted-foreground">{entry.date}</time>
                      </div>

                      <h3 className="text-xl font-bold text-foreground mb-3" style={{ fontFamily: 'var(--font-heading)' }}>{entry.title}</h3>
                      <p className="text-muted-foreground leading-relaxed mb-5">{entry.description}</p>

                      {/* Detail grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="p-3 rounded-lg bg-secondary border border-border">
                          <p className="text-xs font-semibold text-primary mb-1">What We Accomplished</p>
                          <p className="text-sm text-muted-foreground">{entry.accomplished}</p>
                        </div>
                        <div className="p-3 rounded-lg bg-secondary border border-border">
                          <p className="text-xs font-semibold text-accent mb-1">Problems Encountered</p>
                          <p className="text-sm text-muted-foreground">{entry.problems}</p>
                        </div>
                        <div className="p-3 rounded-lg bg-secondary border border-border">
                          <p className="text-xs font-semibold text-foreground mb-1">What We Learned</p>
                          <p className="text-sm text-muted-foreground">{entry.learned}</p>
                        </div>
                        <div className="p-3 rounded-lg bg-secondary border border-border">
                          <p className="text-xs font-semibold text-muted-foreground mb-1">Next Steps</p>
                          <p className="text-sm text-muted-foreground">{entry.next_steps}</p>
                        </div>
                      </div>

                      {/* Photos */}
                      {entry.id === 'week-3' ? (
                        <div className="mt-5">
                          <p className="text-xs font-semibold text-primary mb-3 uppercase tracking-wide">Photos</p>
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                            <img src="https://gccazascendspacerangers.com/airo-assets/images/progress/week-3/photo-1" alt="Team member drilling circuit board in makerspace" className="w-full h-40 object-cover rounded-lg" loading="lazy" />
                            <img src="https://gccazascendspacerangers.com/airo-assets/images/progress/week-3/photo-2" alt="Student holding finished etched PCB" className="w-full h-40 object-cover rounded-lg" loading="lazy" />
                            <img src="https://gccazascendspacerangers.com/airo-assets/images/progress/week-3/photo-3" alt="Close-up of completed copper trace circuit board" className="w-full h-40 object-cover rounded-lg" loading="lazy" />
                            <img src="https://gccazascendspacerangers.com/airo-assets/images/progress/week-3/photo-4" alt="Team member soldering components onto circuit board" className="w-full h-40 object-cover rounded-lg" loading="lazy" />
                            <img src="https://gccazascendspacerangers.com/airo-assets/images/progress/week-3/photo-5" alt="Assembled circuit boards with components on cutting mat" className="w-full h-40 object-cover rounded-lg" loading="lazy" />
                          </div>
                        </div>
                      ) : entry.id === 'week-2' ? (
                        <div className="mt-5">
                          <p className="text-xs font-semibold text-primary mb-3 uppercase tracking-wide">Photos</p>
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                            <img src="https://gccazascendspacerangers.com/airo-assets/images/progress/week-2/photo-1" alt="UV exposure of PCB layout" className="w-full h-40 object-cover rounded-lg" loading="lazy" />
                            <img src="https://gccazascendspacerangers.com/airo-assets/images/progress/week-2/photo-2" alt="Team working in chemistry lab with safety goggles" className="w-full h-40 object-cover rounded-lg" loading="lazy" />
                            <img src="https://gccazascendspacerangers.com/airo-assets/images/progress/week-2/photo-3" alt="Student etching circuit board in fume hood" className="w-full h-40 object-cover rounded-lg" loading="lazy" />
                            <img src="https://gccazascendspacerangers.com/airo-assets/images/progress/week-2/photo-4" alt="Circuit board in ferric chloride etch bath" className="w-full h-40 object-cover rounded-lg" loading="lazy" />
                            <img src="https://gccazascendspacerangers.com/airo-assets/images/progress/week-2/photo-5" alt="Finished etched PCB with copper traces" className="w-full h-40 object-cover rounded-lg" loading="lazy" />
                          </div>
                        </div>
                      ) : (
                        <div className="mt-5 w-full rounded-lg border-2 border-dashed border-border bg-secondary flex items-center justify-center gap-3 py-8 px-4">
                          <svg className="w-6 h-6 text-muted-foreground/40 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                          </svg>
                          <p className="text-sm text-muted-foreground">Add photos for {entry.week} here</p>
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
