import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { flight } from 'virtual:content';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.1 } } };

const statusDot: Record<string, string> = {
  complete: 'bg-primary',
  active: 'bg-accent',
  upcoming: 'bg-border',
};

const statusBadge: Record<string, string> = {
  complete: 'bg-primary/10 text-primary',
  active: 'bg-accent/10 text-accent',
  upcoming: 'bg-muted text-muted-foreground',
};

function statusLabel(s: string) {
  if (s === 'complete') return 'Complete';
  if (s === 'active') return 'In Progress';
  return 'Upcoming';
}

export default function FlightPage() {
  const siteUrl = 'https://gccazascendspacerangers.com';
  return (
    <>
      <Helmet>
        <title>Flight — Space Rangers NASA ASCEND GCC</title>
        <meta name="description" content="From payload integration to recovery — the story of our high-altitude balloon mission." />
        <link rel="canonical" href={`${siteUrl}/flight`} />
        <meta property="og:title" content="Flight — Space Rangers" />
        <meta property="og:description" content="Preparation, launch, ascent, burst, and recovery — our high-altitude balloon mission." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`${siteUrl}/flight`} />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main>
        {/* Hero */}
        <section className="relative pt-0 overflow-hidden min-h-[60vh] flex items-end" style={{ background: 'hsl(var(--surface-navy))' }}>
          <div className="absolute inset-0 pointer-events-none">
            <img
              src="https://gccazascendspacerangers.com/airo-assets/images/pages/flight/hero"
              alt="Weather balloon launch"
              className="w-full h-full object-cover opacity-30"
              loading="eager"
              fetchPriority="high"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--surface-navy))] via-[hsl(var(--surface-navy)/0.4)] to-transparent" />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 pb-20 pt-32 w-full">
            <motion.div initial="hidden" animate="visible" variants={stagger}>
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-accent mb-3">{flight.hero.eyebrow}</motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-accent mb-5" />
              <motion.h1 variants={fadeUp} className="text-4xl md:text-6xl font-bold text-white mb-5 leading-tight" style={{ fontFamily: 'var(--font-heading)' }}>
                {flight.hero.headline}
              </motion.h1>
              <motion.p variants={fadeUp} className="text-lg text-white/70 max-w-2xl leading-relaxed">{flight.hero.subheadline}</motion.p>
            </motion.div>
          </div>
        </section>

        {/* Mission intro + stats */}
        <section className="py-xxl bg-background">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }} variants={stagger} className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">The Mission</motion.p>
                <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
                <motion.h2 variants={fadeUp} className="text-3xl font-bold mb-5" style={{ fontFamily: 'var(--font-heading)' }}>{flight.intro.heading}</motion.h2>
                <motion.p variants={fadeUp} className="text-muted-foreground leading-relaxed">{flight.intro.body}</motion.p>
              </div>
              <motion.div variants={stagger} className="grid grid-cols-2 gap-4">
                {flight.stats.map((stat) => (
                  <motion.div key={stat.id} variants={fadeUp} className="rounded-xl border border-border bg-secondary p-5 text-center">
                    <p className="text-2xl font-bold text-primary mb-1" style={{ fontFamily: 'var(--font-heading)' }}>{stat.value}</p>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>

            {/* Launch date banner */}
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="rounded-xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4" style={{ background: 'hsl(var(--surface-navy))' }}>
              <div>
                <p className="text-xs font-semibold tracking-widest uppercase text-accent mb-1">Launch Date</p>
                <p className="text-2xl font-bold text-white" style={{ fontFamily: 'var(--font-heading)' }}>{flight.launch_date}</p>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-accent/20 border border-accent/30">
                <span className="w-2 h-2 rounded-full bg-accent animate-pulse" />
                <span className="text-sm font-medium text-accent">Upcoming</span>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Flight phases */}
        <section className="py-xxl bg-secondary">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }} variants={stagger} className="mb-12">
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Mission Phases</motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
              <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold" style={{ fontFamily: 'var(--font-heading)' }}>
                Preparation → Launch → Ascent → Burst → Recovery
              </motion.h2>
            </motion.div>

            {/* Phase strip */}
            <div className="hidden md:flex items-center gap-0 mb-12 overflow-x-auto pb-2">
              {flight.phases.map((phase, i) => (
                <div key={phase.id} className="flex items-center shrink-0">
                  <div className="flex flex-col items-center gap-2 px-4">
                    <div className={`w-3 h-3 rounded-full border-2 ${statusDot[phase.status]} border-current`} />
                    <span className="text-xs font-semibold text-foreground whitespace-nowrap">{phase.title}</span>
                  </div>
                  {i < flight.phases.length - 1 && <div className="w-8 h-0.5 bg-border shrink-0" />}
                </div>
              ))}
            </div>

            {/* Phase cards */}
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-60px' }} variants={stagger} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {flight.phases.map((phase, i) => (
                <motion.div key={phase.id} variants={fadeUp} className="rounded-xl border border-border bg-background overflow-hidden">
                  {/* Image placeholder */}
                  <div className="w-full bg-secondary border-b border-border flex flex-col items-center justify-center gap-2 py-10 px-4 text-center">
                    <svg className="w-8 h-8 text-muted-foreground/40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <p className="text-xs text-muted-foreground">{phase.image_caption}</p>
                  </div>
                  <div className="p-5">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-xs font-bold text-muted-foreground">{String(i + 1).padStart(2, '0')}</span>
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${statusBadge[phase.status]}`}>{statusLabel(phase.status)}</span>
                    </div>
                    <h3 className="text-lg font-bold text-foreground mb-2" style={{ fontFamily: 'var(--font-heading)' }}>{phase.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{phase.description}</p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>
      </main>
    </>
  );
}
