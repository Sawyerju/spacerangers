import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { team } from 'virtual:content';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.1 } } };

export default function TeamPage() {
  const siteUrl = 'https://gccazascendspacerangers.com';
  return (
    <>
      <Helmet>
        <title>Meet the Team — Space Rangers NASA ASCEND GCC</title>
        <meta name="description" content="Meet the Space Rangers — a student engineering team at Glendale Community College building a scientific payload for high-altitude balloon flight." />
        <link rel="canonical" href={`${siteUrl}/team`} />
        <meta property="og:title" content="Meet the Team — Space Rangers" />
        <meta property="og:description" content="The students behind the mission — roles, bios, and the people making it happen." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`${siteUrl}/team`} />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main>
        {/* Hero */}
        <section className="relative pt-32 pb-20 overflow-hidden" style={{ background: 'hsl(var(--surface-navy))' }}>
          <div className="absolute inset-0 pointer-events-none">
            <img
              src="https://gccazascendspacerangers.com/airo-assets/images/pages/team/hero"
              alt=""
              aria-hidden="true"
              className="w-full h-full object-cover opacity-20"
              loading="eager"
            />
          </div>
          <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" animate="visible" variants={stagger}>
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-accent mb-3">
                {team.hero.eyebrow}
              </motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-accent mb-5" />
              <motion.h1
                variants={fadeUp}
                className="text-4xl md:text-6xl font-bold text-white mb-5 leading-tight"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {team.hero.headline}
              </motion.h1>
              <motion.p variants={fadeUp} className="text-lg text-white/70 max-w-2xl leading-relaxed">
                {team.hero.subheadline}
              </motion.p>
            </motion.div>
          </div>
        </section>

        {/* Intro */}
        <section className="py-xxl bg-background">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div
              initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }}
              variants={stagger}
              className="max-w-3xl"
            >
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">About Us</motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
              <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
                {team.intro.heading}
              </motion.h2>
              <motion.p variants={fadeUp} className="text-muted-foreground leading-relaxed text-lg">
                {team.intro.body}
              </motion.p>
            </motion.div>
          </div>
        </section>

        {/* Team Members */}
        <section className="py-xxl bg-secondary">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div
              initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }}
              variants={stagger}
              className="mb-12"
            >
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Team Members</motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
              <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold" style={{ fontFamily: 'var(--font-heading)' }}>
                The Crew
              </motion.h2>
            </motion.div>

            <motion.div
              initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-60px' }}
              variants={stagger}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {team.members.map((member) => (
                <motion.div
                  key={member.id}
                  variants={fadeUp}
                  whileHover={{ y: -4 }}
                  transition={{ duration: 0.3, ease: 'easeOut' as const }}
                  className="bg-background rounded-xl border border-border p-6 flex flex-col"
                >
                  {/* Avatar */}
                  <div className="w-20 h-20 rounded-full bg-muted border-2 border-border mb-5 overflow-hidden flex items-center justify-center shrink-0">
                    {member.photo ? (
                      <img
                        src={member.photo}
                        alt={member.name}
                        className="w-full h-full object-cover object-top"
                        loading="lazy"
                      />
                    ) : (
                      <svg className="w-10 h-10 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                    )}
                  </div>

                  <div className="mb-1">
                    <span className="text-xs font-semibold tracking-widest uppercase text-primary">{member.role}</span>
                  </div>
                  <h3 className="text-lg font-bold text-foreground mb-1" style={{ fontFamily: 'var(--font-heading)' }}>
                    {member.name}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4 leading-relaxed flex-1">{member.bio}</p>

                  <div className="pt-4 border-t border-border">
                    <p className="text-xs text-muted-foreground">
                      <span className="font-semibold text-foreground">Major: </span>
                      {member.major}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      <span className="font-semibold text-foreground">Fun fact: </span>
                      {member.fun_fact}
                    </p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* Why ASCEND */}
        <section className="py-xxl bg-secondary">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }} variants={stagger}>
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Our Motivation</motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
              <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold mb-5" style={{ fontFamily: 'var(--font-heading)' }}>
                {team.why_ascend.heading}
              </motion.h2>
              <motion.p variants={fadeUp} className="text-muted-foreground leading-relaxed max-w-3xl mb-12">
                {team.why_ascend.body}
              </motion.p>
              <motion.div variants={stagger} className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {team.why_ascend.reasons.map((reason) => (
                  <motion.div key={reason.id} variants={fadeUp} className="rounded-xl border border-border bg-background p-6">
                    <div className="flex items-center gap-3 mb-3">
                      <span className="w-2 h-2 rounded-full bg-accent shrink-0" />
                      <h3 className="text-base font-bold text-foreground" style={{ fontFamily: 'var(--font-heading)' }}>{reason.title}</h3>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">{reason.body}</p>
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* Faculty Advisors */}
        <section className="py-xxl bg-background">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div
              initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }}
              variants={stagger}
            >
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Faculty</motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
              <motion.h2 variants={fadeUp} className="text-3xl font-bold mb-8" style={{ fontFamily: 'var(--font-heading)' }}>
                Faculty Advisors
              </motion.h2>
              <div className="flex flex-col sm:flex-row gap-6">
                {team.advisors.map((advisor) => (
                  <motion.div
                    key={advisor.id}
                    variants={fadeUp}
                    className="flex flex-col sm:flex-row gap-6 items-start p-6 rounded-xl border border-border bg-secondary flex-1"
                  >
                    <div className="w-16 h-16 rounded-full bg-muted border-2 border-border shrink-0 flex items-center justify-center">
                      <svg className="w-8 h-8 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                    </div>
                    <div>
                      <p className="text-xs font-semibold tracking-widest uppercase text-primary mb-1">{advisor.title}</p>
                      <h3 className="text-lg font-bold text-foreground mb-1" style={{ fontFamily: 'var(--font-heading)' }}>{advisor.name}</h3>
                      <p className="text-sm text-muted-foreground mb-3">{advisor.institution}</p>
                      <p className="text-sm text-muted-foreground leading-relaxed">{advisor.bio}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>
      </main>
    </>
  );
}
