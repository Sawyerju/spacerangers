import { useState, type FormEvent } from 'react';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { Mail, Building2, Rocket } from 'lucide-react';
import { contact } from 'virtual:content';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.1 } } };

type FormStatus = 'idle' | 'sending' | 'success' | 'error';

function ContactForm() {
  const [status, setStatus] = useState<FormStatus>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    if (formData.get('_gotcha')) return;

    const name = String(formData.get('name') ?? '').trim();
    const email = String(formData.get('email') ?? '').trim();
    const subject = String(formData.get('subject') ?? '').trim();
    const message = String(formData.get('message') ?? '').trim();

    setStatus('sending');
    setErrorMsg('');

    try {
      // Field mapping: only the message textarea goes in messages_attributes[0].body.
      // All other fields (subject) go in conversation.data as { "Label": value } pairs.
      const res = await fetch('/api/contact/contact-us', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversation: {
            messages_attributes: [{ body: message || 'New contact form submission' }],
            data: {
              __gd_contact_form_title: 'Space Rangers Contact',
              'Subject': subject,
            },
          },
          user: { email, name },
        }),
      });

      const json = await res.json();
      if (json.success) {
        setStatus('success');
        form.reset();
      } else {
        throw new Error(json.error || 'Something went wrong.');
      }
    } catch (err) {
      setStatus('error');
      setErrorMsg(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5">
      {/* Honeypot — never included in POST body */}
      <input
        type="text"
        name="_gotcha"
        tabIndex={-1}
        autoComplete="off"
        style={{ position: 'absolute', left: '-9999px' }}
        aria-hidden="true"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <div className="flex flex-col gap-1.5">
          <label htmlFor="cf-name" className="text-sm font-semibold text-foreground">Name</label>
          <input
            id="cf-name"
            name="name"
            type="text"
            required
            placeholder="Your name"
            className="px-4 py-2.5 rounded-md border border-border bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-colors"
          />
        </div>
        <div className="flex flex-col gap-1.5">
          <label htmlFor="cf-email" className="text-sm font-semibold text-foreground">Email</label>
          <input
            id="cf-email"
            name="email"
            type="email"
            required
            placeholder="your@email.com"
            className="px-4 py-2.5 rounded-md border border-border bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-colors"
          />
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="cf-subject" className="text-sm font-semibold text-foreground">Subject</label>
        <select
          id="cf-subject"
          name="subject"
          required
          className="px-4 py-2.5 rounded-md border border-border bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-colors"
        >
          <option value="">Select a topic…</option>
          <option value="General Inquiry">General Inquiry</option>
          <option value="Sponsorship Opportunity">Sponsorship Opportunity</option>
          <option value="Media / Press">Media / Press</option>
          <option value="NASA ASCEND Program">NASA ASCEND Program</option>
          <option value="Other">Other</option>
        </select>
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="cf-message" className="text-sm font-semibold text-foreground">Message</label>
        <textarea
          id="cf-message"
          name="message"
          rows={5}
          required
          placeholder="Tell us what's on your mind…"
          className="px-4 py-2.5 rounded-md border border-border bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-colors resize-none"
        />
      </div>

      {status === 'error' && (
        <p role="alert" className="text-sm text-destructive bg-destructive/10 px-4 py-3 rounded-md">{errorMsg}</p>
      )}

      <button
        type="submit"
        disabled={status === 'sending'}
        className="self-start px-7 py-3 rounded-md bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 disabled:opacity-60 transition-colors duration-200"
      >
        {status === 'sending' ? 'Sending…' : 'Send Message'}
      </button>

      {status === 'success' && (
        <p role="status" className="text-sm text-primary bg-primary/10 px-4 py-3 rounded-md font-medium">
          Message sent! We'll get back to you soon.
        </p>
      )}
    </form>
  );
}

const sponsorIcons = [Rocket, Building2, Mail];

export default function ContactPage() {
  const siteUrl = 'https://gccazascendspacerangers.com';
  return (
    <>
      <Helmet>
        <title>Contact & Sponsors — Space Rangers NASA ASCEND GCC</title>
        <meta name="description" content="Get in touch with the Space Rangers team or learn about sponsorship opportunities for our NASA ASCEND high-altitude balloon project." />
        <link rel="canonical" href={`${siteUrl}/contact`} />
        <meta property="og:title" content="Contact & Sponsors — Space Rangers" />
        <meta property="og:description" content="Reach out about sponsorship, media, or general inquiries for our NASA ASCEND project." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`${siteUrl}/contact`} />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main>
        {/* Hero */}
        <section className="relative pt-32 pb-20" style={{ background: 'hsl(var(--surface-navy))' }}>
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" animate="visible" variants={stagger}>
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-accent mb-3">
                {contact.hero.eyebrow}
              </motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-accent mb-5" />
              <motion.h1
                variants={fadeUp}
                className="text-4xl md:text-6xl font-bold text-white mb-5 leading-tight"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {contact.hero.headline}
              </motion.h1>
              <motion.p variants={fadeUp} className="text-lg text-white/70 max-w-2xl leading-relaxed">
                {contact.hero.subheadline}
              </motion.p>
            </motion.div>
          </div>
        </section>

        {/* Contact form + info */}
        <section className="py-xxl bg-background">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div
              initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }}
              variants={stagger}
              className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-16"
            >
              {/* Left: info */}
              <div className="lg:col-span-2">
                <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Contact</motion.p>
                <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
                <motion.h2 variants={fadeUp} className="text-3xl font-bold mb-5" style={{ fontFamily: 'var(--font-heading)' }}>
                  {contact.contact_info.heading}
                </motion.h2>
                <motion.p variants={fadeUp} className="text-muted-foreground leading-relaxed mb-8">
                  {contact.contact_info.body}
                </motion.p>

                <motion.div variants={stagger} className="flex flex-col gap-4">
                  <motion.div variants={fadeUp} className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Mail className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Email</p>
                      <p className="text-sm font-semibold text-foreground">{contact.contact_info.email}</p>
                    </div>
                  </motion.div>
                  <motion.div variants={fadeUp} className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Building2 className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Institution</p>
                      <p className="text-sm font-semibold text-foreground">{contact.contact_info.institution}</p>
                    </div>
                  </motion.div>
                  <motion.div variants={fadeUp} className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Rocket className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Program</p>
                      <p className="text-sm font-semibold text-foreground">{contact.contact_info.program}</p>
                    </div>
                  </motion.div>
                </motion.div>
              </div>

              {/* Right: form */}
              <motion.div variants={fadeUp} className="lg:col-span-3 bg-secondary rounded-2xl border border-border p-6 md:p-8">
                <h3 className="text-lg font-bold text-foreground mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
                  Send Us a Message
                </h3>
                <ContactForm />
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* Sponsors */}
        <section className="py-xxl bg-secondary">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div
              initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-80px' }}
              variants={stagger}
              className="mb-12"
            >
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">Sponsors</motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
              <motion.h2 variants={fadeUp} className="text-3xl md:text-4xl font-bold mb-3" style={{ fontFamily: 'var(--font-heading)' }}>
                {contact.sponsors.heading}
              </motion.h2>
              <motion.p variants={fadeUp} className="text-muted-foreground max-w-2xl">
                {contact.sponsors.subheading}
              </motion.p>
            </motion.div>

            <motion.div
              initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-60px' }}
              variants={stagger}
              className="grid grid-cols-1 md:grid-cols-3 gap-6"
            >
              {contact.sponsors.items.map((sponsor, i) => {
                const Icon = sponsorIcons[i] ?? Rocket;
                const isLast = i === contact.sponsors.items.length - 1;
                return (
                  <motion.div
                    key={sponsor.id}
                    variants={fadeUp}
                    className={`rounded-xl border p-6 ${isLast ? 'border-dashed border-border bg-background' : 'border-border bg-background'}`}
                  >
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <Icon className="w-5 h-5 text-primary" />
                    </div>
                    <span className="text-xs font-semibold tracking-widest uppercase text-primary mb-2 block">{sponsor.tier}</span>
                    <h3 className="text-base font-bold text-foreground mb-2" style={{ fontFamily: 'var(--font-heading)' }}>{sponsor.name}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{sponsor.description}</p>
                  </motion.div>
                );
              })}
            </motion.div>

            {/* Sponsorship CTA */}
            <motion.div
              initial="hidden" whileInView="visible" viewport={{ once: true }}
              variants={fadeUp}
              className="mt-12 p-8 rounded-2xl bg-primary text-white"
            >
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-center">
                <div>
                  <h3 className="text-2xl font-bold mb-3" style={{ fontFamily: 'var(--font-heading)' }}>{contact.sponsorship.heading}</h3>
                  <p className="text-white/75 leading-relaxed">{contact.sponsorship.body}</p>
                </div>
                <div className="lg:text-right">
                  <a
                    href={`mailto:${contact.contact_info.email}`}
                    className="inline-flex items-center gap-2 px-7 py-3.5 rounded-md bg-white text-primary font-semibold text-sm hover:bg-white/90 transition-colors duration-200"
                  >
                    <Mail className="w-4 h-4" />
                    <span>Get in Touch</span>
                  </a>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
    </>
  );
}
