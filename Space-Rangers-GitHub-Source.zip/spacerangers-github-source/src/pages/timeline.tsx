import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { timeline } from 'virtual:content';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' as const } },
};
const stagger = { hidden: {}, visible: { transition: { staggerChildren: 0.1 } } };

const statusDot: Record<string, string> = {
  complete: 'bg-primary border-primary',
  active: 'bg-accent border-accent',
  upcoming: 'bg-background border-border',
};

// Chrome status labels — not user-visible content, UI affordances only
function getStatusLabel(status: string) {
  if (status === 'complete') return 'Complete';
  if (status === 'active') return 'In Progress';
  return 'Upcoming';
}

const statusBadge: Record<string, string> = {
  complete: 'bg-primary/10 text-primary',
  active: 'bg-accent/10 text-accent',
  upcoming: 'bg-muted text-muted-foreground',
};

export default function TimelinePage() {
  const siteUrl = 'https://gccazascendspacerangers.com';
  return (
    <>
      <Helmet>
        <title>Mission Timeline — Space Rangers NASA ASCEND GCC</title>
        <meta name="description" content="Track the Space Rangers' semester progress — every milestone from kickoff to launch day, with dates and status indicators." />
        <link rel="canonical" href={`${siteUrl}/timeline`} />
        <meta property="og:title" content="Mission Timeline — Space Rangers" />
        <meta property="og:description" content="Every milestone from kickoff to launch day, tracked and documented." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={`${siteUrl}/timeline`} />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main>
        {/* Hero */}
        <section className="relative pt-32 pb-20" style={{ background: 'hsl(var(--surface-navy))' }}>
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div initial="hidden" animate="visible" variants={stagger}>
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-accent mb-3">
                {timeline.hero.eyebrow}
              </motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-accent mb-5" />
              <motion.h1
                variants={fadeUp}
                className="text-4xl md:text-6xl font-bold text-white mb-5 leading-tight"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {timeline.hero.headline}
              </motion.h1>
              <motion.p variants={fadeUp} className="text-lg text-white/70 max-w-2xl leading-relaxed">
                {timeline.hero.subheadline}
              </motion.p>
            </motion.div>
          </div>
        </section>

        {/* Timeline */}
        <section className="py-xxl bg-background">
          <div className="max-w-4xl mx-auto px-6 lg:px-8">
            <div className="relative">
              {/* Vertical line */}
              <div className="absolute left-5 top-0 bottom-0 w-0.5 bg-border hidden md:block" />

              <motion.div
                initial="hidden" whileInView="visible" viewport={{ once: true, margin: '-40px' }}
                variants={stagger}
                className="flex flex-col gap-8"
              >
                {timeline.milestones.map((ms) => (
                  <motion.div
                    key={ms.id}
                    variants={fadeUp}
                    className="flex flex-col md:flex-row gap-4 md:gap-8"
                  >
                    {/* Dot */}
                    <div className="hidden md:flex flex-col items-center shrink-0 w-10">
                      <div className={`w-10 h-10 rounded-full border-2 flex items-center justify-center z-10 ${statusDot[ms.status]}`}>
                        {ms.status === 'complete' && (
                          <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                          </svg>
                        )}
                        {ms.status === 'active' && (
                          <span className="w-2.5 h-2.5 rounded-full bg-white" />
                        )}
                      </div>
                    </div>

                    {/* Content */}
                    <div className={`flex-1 rounded-xl border p-5 md:p-6 ${ms.status === 'active' ? 'border-accent/40 bg-accent/5' : 'border-border bg-background'}`}>
                      <div className="flex flex-wrap items-center gap-3 mb-3">
                        <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${statusBadge[ms.status]}`}>
                          {getStatusLabel(ms.status)}
                        </span>
                        <time dateTime={ms.date} className="text-xs text-muted-foreground font-medium">
                          {ms.date}
                        </time>
                        <span className="text-xs text-muted-foreground">Phase {ms.phase}</span>
                      </div>
                      <h3 className="text-lg font-bold text-foreground mb-2" style={{ fontFamily: 'var(--font-heading)' }}>
                        {ms.title}
                      </h3>
                      <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                        {ms.description}
                      </p>
                      <div className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                        <p className="text-xs text-muted-foreground">
                          <span className="font-semibold text-foreground">Deliverable: </span>
                          {ms.deliverable}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
