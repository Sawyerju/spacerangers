import { Link } from 'react-router';
import { Helmet } from '@dr.pogodin/react-helmet';
import { motion } from 'motion/react';
import { ArrowRight, ChevronDown } from 'lucide-react';
import { home } from 'virtual:content';

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' as const } },
};

const stagger = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.1 } },
};

const statusColors: Record<string, string> = {
  complete: 'bg-primary text-primary-foreground',
  active: 'bg-accent text-accent-foreground',
  upcoming: 'bg-muted text-muted-foreground',
};

// Phase status display labels — chrome strings, not user-visible content
const STATUS_LABEL_COMPLETE = 'Complete';
const STATUS_LABEL_ACTIVE = 'In Progress';
const STATUS_LABEL_UPCOMING = 'Upcoming';

function getStatusLabel(status: string) {
  if (status === 'complete') return STATUS_LABEL_COMPLETE;
  if (status === 'active') return STATUS_LABEL_ACTIVE;
  return STATUS_LABEL_UPCOMING;
}

export default function HomePage() {
  const siteUrl = 'https://gccazascendspacerangers.com';

  return (
    <>
      <Helmet>
        <title>Space Rangers — NASA ASCEND Team at Glendale Community College</title>
        <meta name="description" content="Space Rangers is a NASA ASCEND student engineering team at Glendale Community College designing and building a scientific payload for high-altitude balloon flight." />
        <link rel="canonical" href={siteUrl} />
        <meta property="og:title" content="Space Rangers — NASA ASCEND GCC" />
        <meta property="og:description" content="From design to flight — follow our team's engineering journey through the NASA ASCEND program." />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={siteUrl} />
        <meta name="twitter:card" content="summary_large_image" />
      </Helmet>

      <main>
        {/* ── HERO ─────────────────────────────────────────────────── */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          {/* Background image */}
          <img
            src="https://gccazascendspacerangers.com/airo-assets/images/pages/home/hero"
            alt="High-altitude view from a weather balloon"
            className="absolute inset-0 w-full h-full object-cover"
            loading="eager"
            fetchPriority="high"
          />
          {/* Dark navy overlay */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{ background: 'linear-gradient(to bottom, hsl(var(--surface-navy) / 0.75) 0%, hsl(var(--surface-navy) / 0.85) 60%, hsl(var(--surface-navy) / 0.95) 100%)' }}
          />

          {/* Content */}
          <div className="relative z-10 max-w-5xl mx-auto px-6 lg:px-8 text-center text-white">
            <motion.div
              initial="hidden"
              animate="visible"
              variants={stagger}
            >
              {/* Eyebrow */}
              <motion.div variants={fadeUp} className="mb-6">
                <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/20 text-xs font-semibold tracking-widest uppercase text-white/80">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent inline-block" />
                  {home.hero.eyebrow}
                </span>
              </motion.div>

              {/* Headline */}
              <motion.h1
                variants={fadeUp}
                className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold leading-none tracking-tight mb-6"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {home.hero.headline}
              </motion.h1>

              {/* Subheadline */}
              <motion.p
                variants={fadeUp}
                className="text-lg md:text-xl text-white/75 max-w-2xl mx-auto mb-10 leading-relaxed"
              >
                {home.hero.subheadline}
              </motion.p>

              {/* CTAs */}
              <motion.div variants={fadeUp} className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href="#project"
                  className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-md bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 transition-colors duration-200"
                >
                  {home.hero.cta_primary}
                  <ArrowRight className="w-4 h-4" />
                </a>
                <Link
                  to="/team"
                  className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-md border border-white/30 text-white font-semibold text-sm hover:bg-white/10 transition-colors duration-200"
                >
                  {home.hero.cta_secondary}
                </Link>
              </motion.div>
            </motion.div>
          </div>

          {/* Scroll indicator */}
          <motion.div
            className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/50 pointer-events-none"
            animate={{ y: [0, 6, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          >
            <ChevronDown className="w-6 h-6" />
          </motion.div>
        </section>

        {/* ── MISSION OVERVIEW ─────────────────────────────────────── */}
        <section className="py-xxl bg-background">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-80px' }}
              variants={stagger}
              className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center"
            >
              {/* Left: text */}
              <div>
                <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">
                  {home.mission.eyebrow}
                </motion.p>
                <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
                <motion.h2
                  variants={fadeUp}
                  className="text-3xl md:text-4xl font-bold mb-6 leading-tight"
                  style={{ fontFamily: 'var(--font-heading)' }}
                >
                  {home.mission.heading}
                </motion.h2>
                <motion.p variants={fadeUp} className="text-muted-foreground leading-relaxed text-base">
                  {home.mission.body}
                </motion.p>
              </div>

              {/* Right: stats */}
              <motion.div variants={stagger} className="grid grid-cols-1 gap-4">
                {home.mission.stats.map((stat) => (
                  <motion.div
                    key={stat.id}
                    variants={fadeUp}
                    className="flex items-center gap-5 p-5 rounded-lg border border-border bg-secondary"
                  >
                    <div className="w-1 self-stretch rounded-full bg-primary shrink-0" />
                    <div>
                      <p className="text-3xl font-bold text-primary" style={{ fontFamily: 'var(--font-heading)' }}>
                        {stat.value}
                      </p>
                      <p className="text-sm text-muted-foreground font-medium mt-0.5">{stat.label}</p>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* ── ENGINEERING PHASES ───────────────────────────────────── */}
        <section id="project" className="py-xxl bg-secondary scroll-mt-24">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-80px' }}
              variants={stagger}
              className="mb-12"
            >
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">
                {home.phases.eyebrow}
              </motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
              <motion.h2
                variants={fadeUp}
                className="text-3xl md:text-4xl font-bold"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {home.phases.heading}
              </motion.h2>
            </motion.div>

            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-60px' }}
              variants={stagger}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
            >
              {home.phases.items.map((phase) => (
                <motion.div
                  key={phase.id}
                  variants={fadeUp}
                  whileHover={{ y: -4, boxShadow: '0 12px 32px hsl(var(--primary-shadow) / 0.12)' }}
                  transition={{ duration: 0.3, ease: 'easeOut' as const }}
                  className={`relative overflow-hidden rounded-xl border p-6 cursor-default ${
                    phase.status === 'active'
                      ? 'bg-primary border-primary text-primary-foreground'
                      : 'bg-background border-border'
                  }`}
                >
                  {/* Oversized background number */}
                  <span
                    className="absolute -right-3 -bottom-4 text-8xl font-bold leading-none select-none pointer-events-none"
                    style={{
                      color: phase.status === 'active'
                        ? 'rgba(255,255,255,0.08)'
                        : 'hsl(var(--primary) / 0.06)',
                      fontFamily: 'var(--font-heading)',
                    }}
                  >
                    {phase.number}
                  </span>

                  {/* Phase badge */}
                  <div className="flex items-center justify-between mb-4">
                    <span
                      className={`text-xs font-semibold tracking-widest uppercase px-2 py-0.5 rounded ${
                        phase.status === 'active'
                          ? 'bg-white/20 text-white'
                          : statusColors[phase.status]
                      }`}
                    >
                      {getStatusLabel(phase.status)}
                    </span>
                  </div>

                  <h3
                    className={`text-lg font-bold mb-2 ${phase.status === 'active' ? 'text-white' : 'text-foreground'}`}
                    style={{ fontFamily: 'var(--font-heading)' }}
                  >
                    {phase.title}
                  </h3>
                  <p className={`text-sm leading-relaxed ${phase.status === 'active' ? 'text-white/80' : 'text-muted-foreground'}`}>
                    {phase.description}
                  </p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* ── TIMELINE PREVIEW ─────────────────────────────────────── */}
        <section id="timeline" className="py-xxl bg-background scroll-mt-24">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-80px' }}
              variants={stagger}
              className="mb-10"
            >
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">
                {home.timeline_preview.eyebrow}
              </motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
              <motion.h2
                variants={fadeUp}
                className="text-3xl md:text-4xl font-bold"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {home.timeline_preview.heading}
              </motion.h2>
            </motion.div>

            {/* Timeline strip */}
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-60px' }}
              variants={stagger}
              className="relative"
            >
              {/* Connecting line */}
              <div className="absolute top-5 left-0 right-0 h-0.5 bg-border hidden md:block" />

              <div className="grid grid-cols-1 md:grid-cols-5 gap-6 md:gap-4">
                {home.timeline_preview.milestones.map((ms) => (
                  <motion.div key={ms.id} variants={fadeUp} className="flex flex-col items-center text-center">
                    {/* Dot */}
                    <div
                      className={`relative z-10 w-10 h-10 rounded-full flex items-center justify-center mb-3 border-2 ${
                        ms.status === 'complete'
                          ? 'bg-primary border-primary'
                          : ms.status === 'active'
                          ? 'bg-accent border-accent'
                          : 'bg-background border-border'
                      }`}
                    >
                      {ms.status === 'complete' && (
                        <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                      {ms.status === 'active' && (
                        <span className="w-2.5 h-2.5 rounded-full bg-white" />
                      )}
                    </div>
                    <p className="text-sm font-semibold text-foreground">{ms.label}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{ms.date}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              className="mt-10 text-center"
            >
              <a
                href="#timeline"
                className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:text-primary/80 transition-colors"
              >
                {home.timeline_preview.cta}
                <ArrowRight className="w-4 h-4" />
              </a>
            </motion.div>
          </div>
        </section>

        {/* ── TEAM PREVIEW ─────────────────────────────────────────── */}
        <section className="py-xxl bg-secondary">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-80px' }}
              variants={stagger}
              className="mb-10"
            >
              <motion.p variants={fadeUp} className="text-xs font-semibold tracking-widest uppercase text-primary mb-3">
                {home.team_preview.eyebrow}
              </motion.p>
              <motion.div variants={fadeUp} className="w-8 h-0.5 bg-primary mb-5" />
              <motion.h2
                variants={fadeUp}
                className="text-3xl md:text-4xl font-bold"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {home.team_preview.heading}
              </motion.h2>
            </motion.div>

            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-60px' }}
              variants={stagger}
              className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-5"
            >
              {(home.team_preview.members as Array<{ id: string; name: string; role: string; photo?: string }>).map((member) => (
                <motion.div
                  key={member.id}
                  variants={fadeUp}
                  whileHover={{ y: -3 }}
                  transition={{ duration: 0.3, ease: 'easeOut' as const }}
                  className="bg-background rounded-xl border border-border overflow-hidden text-center"
                >
                  {/* Headshot */}
                  <div className="w-full aspect-square overflow-hidden bg-muted">
                    {member.photo ? (
                      <img
                        src={member.photo}
                        alt={member.name}
                        className="w-full h-full object-cover object-top"
                        loading="lazy"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <svg className="w-10 h-10 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <p className="font-semibold text-foreground text-sm">{member.name}</p>
                    <p className="text-xs text-muted-foreground mt-1">{member.role}</p>
                  </div>
                </motion.div>
              ))}
            </motion.div>

            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
              className="mt-10 text-center"
            >
              <Link
                to="/team"
                className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:text-primary/80 transition-colors"
              >
                {home.team_preview.cta}
                <ArrowRight className="w-4 h-4" />
              </Link>
            </motion.div>
          </div>
        </section>

        {/* ── CTA SECTION ──────────────────────────────────────────── */}
        <section className="py-xxl bg-primary">
          <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: '-80px' }}
              variants={stagger}
              className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center"
            >
              <motion.h2
                variants={fadeUp}
                className="text-4xl md:text-5xl font-bold text-white leading-tight"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {home.cta_section.heading}
              </motion.h2>
              <motion.div variants={fadeUp} className="flex flex-col gap-6">
                <p className="text-white/75 text-lg leading-relaxed">
                  {home.cta_section.body}
                </p>
                <div>
                  <a
                    href="#timeline"
                    className="inline-flex items-center gap-2 px-7 py-3.5 rounded-md bg-white text-primary font-semibold text-sm hover:bg-white/90 transition-colors duration-200"
                  >
                    {home.cta_section.cta}
                    <ArrowRight className="w-4 h-4" />
                  </a>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </section>
      </main>
    </>
  );
}
