/**
 * Portable replacement for Airo's generated `virtual:content` module.
 *
 * The public-site content below was reconstructed from the published site at
 * https://gccazascendspacerangers.com/ so this repository can run outside Airo.
 */

const asset = (path: string) => `https://gccazascendspacerangers.com/airo-assets/${path.replace(/^\//, '')}`;

const teamMembers = [
  {
    id: 'sawyer',
    name: 'Sawyer Jungeman',
    role: 'Project Lead',
    major: 'Mechanical Engineering',
    bio: 'Leads the team by coordinating the overall project, managing timelines, and keeping everyone informed and on track. He enjoys solving problems, bringing the team together, and helping turn ideas into solutions.',
    fun_fact: 'Enjoys spending time outdoors.',
    photo: asset('images/team/sawyer'),
  },
  {
    id: 'caleb',
    name: 'Caleb Maxson',
    role: 'Co-project Lead',
    major: 'Aerospace Engineering',
    bio: 'Supports the Project Lead in coordinating the team, keeping the project on track, and helping with planning. Caleb plans to transfer to ASU and hopes to one day work in the space industry.',
    fun_fact: 'His middle name is Owen, and he shares it with his dad!',
    photo: asset('images/team/caleb'),
  },
  {
    id: 'jordan',
    name: 'Jordan Dominguez',
    role: 'Systems & Software Lead',
    major: 'Computer Science',
    bio: 'Manages the team’s software, digital systems, and technical development. She has a passion for programming and a strong curiosity about how software and code interact with the physical world.',
    fun_fact: 'Loves playing pickleball and working out in her free time.',
    photo: asset('images/team/jordan'),
  },
  {
    id: 'elie',
    name: 'Elie Saroian',
    role: 'Media & Documentation Lead',
    major: 'Electrical Engineering',
    bio: 'Captures photos and documents the team’s progress throughout the project. He attends GCC and ASU concurrently and is excited to learn, contribute, and be part of the ASCEND team this year.',
    fun_fact: 'Likes to play videogames and listen to music in his free time.',
    photo: asset('images/team/elie'),
  },
  {
    id: 'isaiah',
    name: 'Isaiah Cardenas',
    role: 'Web Development Lead',
    major: 'Civil Engineering',
    bio: 'Designs and maintains the team’s website while documenting our progress throughout the project. He is also focused on learning, growing, and developing the skills and mindset of an engineer.',
    fun_fact: 'Loves sports, especially basketball, and enjoys spending time with good friends.',
    photo: asset('images/team/isaiah'),
  },
];

export const home = {
  hero: {
    eyebrow: 'NASA ASCEND — GCC',
    headline: 'Design. Build. Test. Fly.',
    subheadline: 'Space Rangers is a student engineering team at Glendale Community College building a scientific payload for high-altitude balloon flight.',
    cta_primary: 'Our Project',
    cta_secondary: 'Meet the Team',
  },
  mission: {
    eyebrow: 'Our Mission',
    heading: 'Real Science. Real Engineering.',
    body: "Through NASA's ASCEND program, the Space Rangers are tackling the full engineering lifecycle — from initial research and payload design to construction, testing, and a real high-altitude flight. Every decision is documented, every result analyzed. This is what student science looks like when the stakes are real.",
    stats: [
      { id: 'engineering-phases', value: '6', label: 'Engineering Phases' },
      { id: 'payload-count', value: '1', label: 'Scientific Payload' },
      { id: 'target-altitude', value: '~100,000 ft', label: 'Target Altitude' },
    ],
  },
  phases: {
    eyebrow: 'Engineering Process',
    heading: 'From Concept to Stratosphere',
    items: [
      { id: 'research', number: '01', title: 'Research', description: 'Define the scientific objective, review prior work, and establish mission requirements.', status: 'complete' },
      { id: 'design', number: '02', title: 'Design', description: 'Develop payload architecture, select components, and produce engineering drawings.', status: 'complete' },
      { id: 'construction', number: '03', title: 'Construction', description: 'Fabricate and assemble the payload enclosure, sensors, and data systems.', status: 'active' },
      { id: 'testing', number: '04', title: 'Testing', description: 'Validate performance under simulated conditions and iterate on design.', status: 'upcoming' },
      { id: 'flight', number: '05', title: 'Flight', description: 'Launch the payload aboard a high-altitude weather balloon and collect live data.', status: 'upcoming' },
      { id: 'results', number: '06', title: 'Results', description: 'Analyze flight data, draw scientific conclusions, and present findings.', status: 'upcoming' },
    ],
  },
  timeline_preview: {
    eyebrow: 'Semester Progress',
    heading: 'Mission Timeline',
    cta: 'View Full Timeline',
    milestones: [
      { id: 'kickoff', label: 'Kickoff', date: 'Aug 2026', status: 'complete' },
      { id: 'research-review', label: 'Research Review', date: 'Sep 2026', status: 'complete' },
      { id: 'design-freeze', label: 'Design Freeze', date: 'Oct 2026', status: 'active' },
      { id: 'build-complete', label: 'Build Complete', date: 'Nov 2026', status: 'upcoming' },
      { id: 'launch-day', label: 'Launch Day', date: 'Dec 2026', status: 'upcoming' },
    ],
  },
  team_preview: {
    eyebrow: 'The Team',
    heading: 'Meet the Space Rangers',
    cta: 'Meet the Full Team',
    members: teamMembers,
  },
  cta_section: {
    heading: 'Follow Our Mission',
    body: 'Track every phase of our engineering journey — from the first design sketch to the moment our payload reaches the stratosphere.',
    cta: 'View Full Timeline',
  },
};

export const team = {
  hero: {
    eyebrow: 'The Team',
    headline: 'Meet the Space Rangers',
    subheadline: 'A group of Glendale Community College students united by curiosity, engineering, and the drive to send something to the stratosphere.',
  },
  intro: {
    heading: 'Who We Are',
    body: "The Space Rangers are a team of engineering and computer science students at Glendale Community College participating in NASA's ASCEND program.",
  },
  members: teamMembers,
  why_ascend: {
    heading: 'Why ASCEND?',
    body: "We joined the NASA ASCEND program because it offers something most college courses can't — a real engineering challenge with real stakes.",
    reasons: [
      { id: 'real-engineering', title: 'Real Engineering Experience', body: 'ASCEND gives us the chance to go through the full engineering design process.' },
      { id: 'nasa-mentorship', title: 'NASA Mentorship', body: 'Working within the NASA ASCEND framework connects us to professional engineers.' },
      { id: 'scientific-contribution', title: 'Scientific Contribution', body: 'Our payload will collect real atmospheric data at altitudes most people never reach.' },
      { id: 'team-growth', title: 'Team Growth', body: 'Engineering is a team sport. ASCEND teaches us how to collaborate under pressure.' },
    ],
  },
  advisors: [
    {
      id: 'tim-frank',
      title: 'NASA ASCEND Program Advisor',
      name: 'Dr. Tim Frank',
      institution: 'Glendale Community College',
      bio: 'Our faculty advisor guides the Space Rangers through the NASA ASCEND program, providing mentorship and technical guidance throughout every phase.',
    },
    {
      id: 'rick-sparber',
      title: 'Faculty Advisor',
      name: 'Rick Sparber',
      institution: 'Glendale Community College',
      bio: 'Rick Sparber brings valuable expertise and support to the Space Rangers team, helping guide students through the challenges of real-world engineering.',
    },
  ],
};

export const payload = {
  hero: {
    eyebrow: 'Our Payload',
    headline: 'Our Payload',
    subheadline: "The science, the hardware, and the engineering behind what we're sending to the stratosphere.",
  },
  mission: {
    heading: 'Mission Objective',
    body: 'Design, build, and fly a scientific payload aboard a high-altitude weather balloon to collect atmospheric data at altitudes up to approximately 100,000 feet, and compare our measurements against established atmospheric models.',
    question: 'How do temperature, pressure, and humidity change with altitude through the troposphere and into the stratosphere, and how closely do our measurements match the International Standard Atmosphere model?',
  },
  experiment: {
    heading: 'Our Experiment',
    body: 'Our payload will continuously log temperature, barometric pressure, and relative humidity from ground level through the stratosphere. By comparing our recorded data against the ISA model, we can evaluate sensor accuracy at extreme conditions and identify any atmospheric anomalies during our specific flight.',
    hypothesis: 'We expect temperature to decrease at approximately 6.5°C per 1,000 meters through the troposphere, then stabilize or slightly increase in the lower stratosphere. Pressure will decrease exponentially with altitude. Humidity will drop sharply above the tropopause.',
  },
  overview: {
    heading: 'Payload Overview',
    body: 'Our payload is a compact, lightweight enclosure housing a sensor suite, microcontroller, and data logger. It is designed to survive temperatures as low as -60°C, fit within the program size and weight limits, and return safely via parachute after balloon burst.',
    image_caption: 'Payload enclosure — add your photo here',
  },
  components: [
    { id: 'bme280', category: 'Sensors', name: 'BME280 Sensor', description: 'Measures temperature, barometric pressure, and relative humidity. Accurate to ±1°C and ±1 hPa.' },
    { id: 'gps', category: 'Sensors', name: 'GPS Module', description: 'Tracks altitude, latitude, longitude, and ground speed throughout the flight.' },
    { id: 'arduino', category: 'Microcontroller', name: 'Arduino Nano', description: 'Main processing unit. Reads all sensors and writes data to the SD card logger at 1-second intervals.' },
    { id: 'sd-card', category: 'Data Storage', name: 'SD Card Logger', description: 'Logs all sensor readings with timestamps to a microSD card for post-flight analysis.' },
    { id: 'batteries', category: 'Power', name: '3× AA Lithium Batteries', description: 'Lithium batteries maintain performance at low temperatures where alkaline batteries fail.' },
    { id: 'foam', category: 'Structure', name: 'Foam Enclosure', description: 'Lightweight expanded polystyrene enclosure provides thermal insulation and impact protection.' },
  ],
  data: {
    heading: 'Data We Plan to Collect',
    items: [
      { id: 'temperature', label: 'Temperature', detail: '°C, logged every second from ground to burst altitude' },
      { id: 'pressure', label: 'Barometric Pressure', detail: 'hPa, logged every second' },
      { id: 'humidity', label: 'Relative Humidity', detail: '%, logged every second' },
      { id: 'gps-altitude', label: 'GPS Altitude', detail: 'meters above sea level, logged every second' },
      { id: 'coordinates', label: 'GPS Coordinates', detail: 'Latitude and longitude for flight path mapping' },
      { id: 'ground-speed', label: 'Ground Speed', detail: 'km/h, for wind drift analysis' },
    ],
  },
  expected: {
    heading: 'Expected Results',
    body: 'We expect our data to closely follow the ISA model through the troposphere, with temperature decreasing at the standard lapse rate. We anticipate finding the tropopause — where temperature stops decreasing — at approximately 11–12 km altitude. Humidity should drop to near zero above the tropopause. Any deviations from the model will be the most scientifically interesting part of our analysis.',
  },
};

export const progress = {
  hero: {
    eyebrow: 'Project Progress',
    headline: 'Progress Log',
    subheadline: 'A week-by-week record of our work — what we built, what we learned, and what comes next.',
  },
  entries: [
    {
      id: 'week-1', week: 'Week 1', date: 'August 25, 2026', status: 'complete',
      title: 'Getting Started with NASA ASCEND',
      description: 'Our first week of NASA ASCEND focused on introducing the project, forming our team, and learning about the Flight Data Recorder (FDR) that will be used as part of the payload. We were introduced to the expectations for the semester and began learning about the process of building and testing hardware for a high-altitude balloon project.',
      accomplished: 'We formed our NASA ASCEND team, learned about the Flight Data Recorder, and assigned our initial team responsibilities, including leadership, media, and website development.',
      problems: 'As a new team, we were still getting familiar with the project, the equipment, and how our different responsibilities would work together.',
      learned: 'We learned more about the purpose of the Flight Data Recorder and what would be expected of us as an ASCEND team.',
      next_steps: 'Begin working with the electronics and circuit boards, learn the manufacturing process, and continue developing our team and project website.',
    },
    {
      id: 'week-2', week: 'Week 2', date: 'September 1, 2026', status: 'complete',
      title: 'Creating Our First Circuit Boards',
      description: 'This week, we began learning how circuit boards are made and worked in the chemistry lab to create our first etched boards. Our first attempt did not turn out as expected, which gave us an opportunity to identify problems and learn from the process.',
      accomplished: 'We went into the chemistry lab and etched our first circuit boards. We also continued learning about the Flight Data Recorder and began developing our hands-on electronics skills.',
      problems: 'Our first etched circuit boards did not turn out well enough for us to use, so we needed to figure out what went wrong and make improvements before moving forward.',
      learned: 'We learned the basic process of creating circuit boards and how important accuracy and attention to detail are when manufacturing them.',
      next_steps: 'Work with our ASCEND advisor, Rick, to create improved circuit boards, then drill the boards and begin soldering the necessary components.',
    },
    {
      id: 'week-3', week: 'Week 3', date: 'September 8, 2026', status: 'complete',
      title: 'Drilling, Soldering, and Team Building',
      description: 'Rick took our circuit boards home and built them for both ASCEND teams. With finished boards in hand, we drilled the holes, soldered all the components, and started our Arduino lab. We also did a team-building engineering activity focused on communication and problem-solving.',
      accomplished: 'Drilled and soldered our circuit boards, began the Arduino lab, and completed a team-building exercise.',
      problems: "Our original etched boards didn't come out well enough to use, so we had Rick take them home and build new ones for both teams.",
      learned: 'Proper drilling and soldering technique, and how clear communication makes a big difference when working as a team.',
      next_steps: 'Continue the Arduino lab and keep building out the Flight Data Recorder.',
    },
    {
      id: 'week-4', week: 'Week 4', date: 'September 15, 2026', status: 'complete',
      title: 'Preliminary Design',
      description: 'Created the first version of our payload design. Selected final sensors and microcontroller. Produced initial CAD sketches and a preliminary bill of materials.',
      accomplished: 'Preliminary design complete, sensors selected (BME280 + GPS), BOM drafted.',
      problems: 'Power budget was tight — switched to lithium batteries for better cold-weather performance.',
      learned: 'How to create a power budget and why battery chemistry matters at altitude.',
      next_steps: 'Preliminary Design Review with faculty advisor.',
    },
    {
      id: 'week-5', week: 'Week 5', date: 'September 22, 2026', status: 'upcoming',
      title: 'Design Review',
      description: 'Present our preliminary design to the faculty advisor. Incorporate feedback and finalize the design before construction begins.',
      accomplished: 'Add your accomplishments here.',
      problems: 'Add any problems encountered here.',
      learned: 'Add what you learned here.',
      next_steps: 'Finalize design and begin construction.',
    },
    {
      id: 'build-phase', week: 'Build Phase', date: 'October 2026', status: 'upcoming',
      title: 'Construction',
      description: 'Fabricating the payload enclosure, assembling the circuit board, and programming the Arduino data logger. Weekly build sessions in the engineering lab.',
      accomplished: 'Add your accomplishments here.',
      problems: 'Add any problems encountered here.',
      learned: 'Add what you learned here.',
      next_steps: 'Complete build and begin testing.',
    },
    {
      id: 'testing', week: 'Testing', date: 'November 2026', status: 'upcoming',
      title: 'Testing & Iteration',
      description: 'Environmental testing, data logging verification, and drop tests. Iterating on any failures before flight clearance.',
      accomplished: 'Add your accomplishments here.',
      problems: 'Add any problems encountered here.',
      learned: 'Add what you learned here.',
      next_steps: 'Pass flight readiness review.',
    },
    {
      id: 'flight-day', week: 'Flight Day', date: 'December 5, 2026', status: 'upcoming',
      title: 'Launch & Recovery',
      description: 'Launch day. Balloon inflation, payload integration, launch, ascent to ~100,000 ft, burst, descent, and recovery.',
      accomplished: 'Add your accomplishments here.',
      problems: 'Add any problems encountered here.',
      learned: 'Add what you learned here.',
      next_steps: 'Analyze flight data.',
    },
    {
      id: 'results', week: 'Results', date: 'December 2026', status: 'upcoming',
      title: 'Data Analysis',
      description: 'Processing flight data, comparing against atmospheric models, and preparing the final report and presentation.',
      accomplished: 'Add your accomplishments here.',
      problems: 'Add any problems encountered here.',
      learned: 'Add what you learned here.',
      next_steps: 'Submit final report to NASA ASCEND.',
    },
  ],
};

export const design = {
  hero: {
    eyebrow: 'Design & Engineering',
    headline: 'Design & Engineering',
    subheadline: 'The full engineering process behind our payload — from initial research through final design.',
  },
  sections: [
    { id: 'research', title: 'Research', body: 'Before designing anything, we studied the problem. We reviewed atmospheric science literature, analyzed data from prior ASCEND payloads, and identified the key variables we wanted to measure. Our research established the scientific foundation for every design decision that followed.', image_caption: 'Add your research notes or reference images here' },
    { id: 'brainstorming', title: 'Brainstorming', body: 'We generated multiple payload concepts before selecting our approach. Each concept was evaluated against our mission requirements: scientific value, weight, power consumption, cost, and buildability. We documented our trade-off analysis and selected the concept that best balanced all constraints.', image_caption: 'Add your brainstorming sketches or concept diagrams here' },
    { id: 'design', title: 'Design', body: 'Our final payload design uses a BME280 sensor for temperature, pressure, and humidity measurements, a GPS module for altitude tracking, and an Arduino Nano as the central microcontroller. All data is logged to a microSD card at 1-second intervals. The enclosure is fabricated from expanded polystyrene for thermal insulation and impact protection.', image_caption: 'Add your CAD drawings or design diagrams here' },
    { id: 'calculations', title: 'Engineering Calculations', body: 'Add your engineering calculations here — power budget, thermal analysis, weight budget, parachute sizing, and any other technical calculations relevant to your payload design.', image_caption: 'Add your calculation sheets or technical diagrams here' },
    { id: 'system-design', title: 'System Design', body: 'The payload system consists of four subsystems: the sensor suite (BME280 + GPS), the processing unit (Arduino Nano), the data storage system (SD card logger), and the power system (3× AA lithium batteries). All subsystems are integrated on a single circuit board inside the foam enclosure.', image_caption: 'Add your system block diagram here' },
    { id: 'mechanical', title: 'Mechanical Design', body: 'The payload enclosure is constructed from 1-inch expanded polystyrene foam board, cut and assembled to form a sealed box. The enclosure provides thermal insulation to protect electronics from temperatures as low as -60°C at altitude. A parachute attachment point is integrated into the top of the enclosure.', image_caption: 'Add your mechanical drawings or enclosure photos here' },
    { id: 'electrical', title: 'Electrical System', body: 'The electrical system centers on the Arduino Nano, which reads the BME280 sensor via I2C and the GPS module via serial communication. Data is written to the SD card logger at 1-second intervals. The system is powered by three AA lithium batteries providing approximately 4.5V, regulated to 3.3V for the sensors.', image_caption: 'Add your wiring diagram or circuit board photos here' },
    { id: 'testing', title: 'Testing', body: 'Our testing plan includes cold chamber testing to simulate high-altitude temperatures, vibration testing to simulate balloon ascent, data logging verification to confirm sensor accuracy, and a drop test to verify parachute deployment. We will document all test results and iterate on any failures before flight.', image_caption: 'Add your test setup photos or test result data here' },
  ],
};

export const flight = {
  hero: {
    eyebrow: 'Flight Day',
    headline: 'Flight',
    subheadline: 'From payload integration to recovery — the story of our high-altitude balloon mission.',
  },
  intro: {
    heading: 'The Mission',
    body: 'After months of design, construction, and testing, everything comes down to flight day. Our payload will ascend to approximately 100,000 feet aboard a high-altitude weather balloon, collect atmospheric data through the troposphere and into the stratosphere, then descend via parachute for recovery and data extraction.',
  },
  stats: [
    { id: 'target-altitude', value: '~100,000 ft', label: 'Target Altitude' },
    { id: 'ascent-rate', value: '~1,000 ft/min', label: 'Ascent Rate' },
    { id: 'flight-duration', value: '~2–3 hours', label: 'Flight Duration' },
    { id: 'burst-diameter', value: '~8 meters', label: 'Burst Diameter' },
  ],
  launch_date: 'December 5, 2026',
  phases: [
    { id: 'preparation', title: 'Preparation', description: 'Final payload inspection, data logger verification, battery installation, and enclosure sealing. Pre-flight checklist completed and signed off.', image_caption: 'Add your pre-flight preparation photos here', status: 'upcoming' },
    { id: 'integration', title: 'Payload Integration', description: 'Attaching our payload to the balloon train. Verifying all connections, confirming GPS lock, and confirming data logging is active before handoff.', image_caption: 'Add your payload integration photos here', status: 'upcoming' },
    { id: 'launch', title: 'Launch', description: 'Balloon inflation with helium, final weather check, and release. The balloon ascends at approximately 1,000 feet per minute.', image_caption: 'Add your launch day photos here', status: 'upcoming' },
    { id: 'ascent', title: 'Ascent', description: 'The balloon climbs through the troposphere and into the stratosphere. Our sensors log temperature, pressure, and humidity every second. The balloon expands as atmospheric pressure decreases.', image_caption: 'Add your ascent data or in-flight photos here', status: 'upcoming' },
    { id: 'burst', title: 'Burst & Descent', description: 'At approximately 100,000 feet, the balloon bursts. The payload separates and descends via parachute, continuing to log data on the way down.', image_caption: 'Add your burst altitude data or descent photos here', status: 'upcoming' },
    { id: 'recovery', title: 'Recovery', description: 'Using GPS coordinates logged by our payload, we locate and recover the payload. Data is extracted from the SD card for analysis.', image_caption: 'Add your recovery photos here', status: 'upcoming' },
  ],
};

export const results = {
  hero: {
    eyebrow: 'Results',
    headline: 'Results',
    subheadline: 'What our payload collected, what the data showed, and what we learned from the experience.',
  },
  status: {
    heading: 'Flight Status',
    body: 'This page will be updated after our flight on December 5, 2026. Check back after launch day for our full data analysis, graphs, and findings.',
  },
  data_sections: [
    { id: 'data-collected', title: 'Data Collected', body: 'Add a summary of the data your payload collected here — total data points, flight duration, maximum altitude reached, and any notable observations.', image_caption: 'Add your raw data table or data summary here' },
    { id: 'temperature', title: 'Temperature vs. Altitude', body: 'Add your temperature profile graph here. Describe what the data shows — did temperature decrease at the expected lapse rate? Did you find the tropopause? Were there any anomalies?', image_caption: 'Add your temperature vs. altitude graph here' },
    { id: 'pressure', title: 'Pressure vs. Altitude', body: 'Add your pressure profile graph here. Describe how pressure changed with altitude and how it compared to the ISA model.', image_caption: 'Add your pressure vs. altitude graph here' },
    { id: 'humidity', title: 'Humidity vs. Altitude', body: 'Add your humidity profile graph here. Describe how humidity changed with altitude — did it drop sharply above the tropopause as expected?', image_caption: 'Add your humidity vs. altitude graph here' },
    { id: 'expected-actual', title: 'Expected vs. Actual Results', body: 'Add your comparison between predicted and actual results here. Where did your data match the ISA model? Where did it differ? What might explain any differences?', image_caption: 'Add your comparison chart or overlay graph here' },
  ],
  lessons: {
    heading: 'What We Learned',
    intro: 'From the first idea to flight day, this project gave us the opportunity to experience the engineering process firsthand.',
    items: [
      { id: 'engineering-challenges', category: 'Engineering Challenges', body: 'Add the engineering challenges your team faced here.' },
      { id: 'problems-solutions', category: 'Problems & Solutions', body: 'Add the problems you encountered and how you solved them here.' },
      { id: 'what-worked', category: 'What Worked', body: 'Add what worked well in your design and process here.' },
      { id: 'what-didnt-work', category: "What Didn't Work", body: "Add what didn't work as expected and what you would change here." },
      { id: 'teamwork', category: 'Teamwork', body: 'Add reflections on your team experience — communication, collaboration, and what you learned about working as an engineering team.' },
      { id: 'skills', category: 'Skills Developed', body: 'Add the engineering and technical skills you developed throughout the project here.' },
      { id: 'future', category: 'Future Improvements', body: 'Add what you would improve or do differently if you built this payload again.' },
    ],
    closing: 'From the first idea to flight day, this project gave us the opportunity to experience the engineering process firsthand.',
  },
};

// These three pages were present in the extracted project source but are not
// currently published as routes on the custom-domain site. They remain here so
// the extracted files still compile and can be re-enabled later if desired.
export const project = {
  hero: { eyebrow: 'Our Project', headline: 'Engineering the Payload', subheadline: 'Full engineering documentation from research and design through construction, testing, flight, and results.' },
  overview: { heading: 'Project Overview', body: 'The Space Rangers are developing a scientific payload for a NASA ASCEND high-altitude balloon mission at Glendale Community College.', objective: 'Design, build, test, and fly a reliable scientific payload while documenting the complete engineering process.' },
  specs: { heading: 'Mission at a Glance', items: [
    { id: 'sp1', label: 'Program', value: 'NASA ASCEND' },
    { id: 'sp2', label: 'Institution', value: 'Glendale Community College' },
    { id: 'sp3', label: 'Platform', value: 'High-Altitude Balloon' },
    { id: 'sp4', label: 'Status', value: 'In Development' },
  ]},
  phases: [
    { id: 'pp1', number: '01', title: 'Research', details: 'Define mission objectives, constraints, and measurement requirements.', deliverables: ['Mission objective', 'Requirements', 'Initial architecture'], status: 'complete' },
    { id: 'pp2', number: '02', title: 'Design', details: 'Develop and iterate the mechanical, electrical, and software design.', deliverables: ['CAD', 'Circuit architecture', 'Design review'], status: 'active' },
    { id: 'pp3', number: '03', title: 'Construction', details: 'Fabricate hardware, assemble electronics, and integrate subsystems.', deliverables: ['Flight structure', 'Electronics assembly', 'Integrated payload'], status: 'upcoming' },
    { id: 'pp4', number: '04', title: 'Testing', details: 'Verify requirements and system performance before launch.', deliverables: ['Bench testing', 'System validation', 'Flight readiness'], status: 'upcoming' },
    { id: 'pp5', number: '05', title: 'Flight', details: 'Launch, operate, track, and recover the payload.', deliverables: ['Launch', 'Data collection', 'Recovery'], status: 'upcoming' },
    { id: 'pp6', number: '06', title: 'Results', details: 'Analyze the collected data and capture engineering lessons learned.', deliverables: ['Data analysis', 'Results', 'Final documentation'], status: 'upcoming' },
  ],
};

export const timeline = {
  hero: { eyebrow: 'Mission Timeline', headline: 'From Kickoff to Launch Day', subheadline: 'Every major milestone in the Space Rangers engineering process.' },
  milestones: [
    { id: 'tm1', date: 'Aug 2026', phase: '1', title: 'Kickoff', description: 'Project kickoff and team formation.', deliverable: 'Team formed', status: 'complete' },
    { id: 'tm2', date: 'Sep 2026', phase: '2', title: 'Research Review', description: 'Review research and mission requirements.', deliverable: 'Research review', status: 'complete' },
    { id: 'tm3', date: 'Oct 2026', phase: '3', title: 'Design Freeze', description: 'Finalize the payload design before construction.', deliverable: 'Frozen design', status: 'active' },
    { id: 'tm4', date: 'Nov 2026', phase: '4', title: 'Build Complete', description: 'Complete build and system testing.', deliverable: 'Flight-ready payload', status: 'upcoming' },
    { id: 'tm5', date: 'Dec 2026', phase: '5', title: 'Launch Day', description: 'Launch, fly, and recover the payload.', deliverable: 'Flight dataset', status: 'upcoming' },
  ],
};

export const contact = {
  hero: { eyebrow: 'Contact', headline: 'Connect with the Space Rangers', subheadline: 'Questions, sponsorship opportunities, media requests, or interest in the NASA ASCEND project.' },
  contact_info: { heading: 'Get in Touch', body: 'We welcome questions about the project and opportunities to support student engineering.', email: 'replace-with-team-email@example.com', institution: 'Glendale Community College', program: 'NASA ASCEND' },
  sponsors: { heading: 'Mission Supporters', subheading: 'Organizations and partners helping make student aerospace engineering possible.', items: [
    { id: 'sponsor-1', tier: 'Program', name: 'NASA ASCEND', description: 'High-altitude balloon program supporting student engineering and science.' },
    { id: 'sponsor-2', tier: 'Institution', name: 'Glendale Community College', description: 'Home institution of the Space Rangers student engineering team.' },
    { id: 'sponsor-3', tier: 'Open', name: 'Become a Sponsor', description: 'Add additional partners and sponsorship information here.' },
  ]},
  sponsorship: { heading: 'Support the Mission', body: 'Interested in supporting student engineering, fabrication, testing, or flight operations? Contact the team.' },
};
