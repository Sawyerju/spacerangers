import type { RouteObject } from 'react-router';
import HomePage from './pages/index';
import TeamPage from './pages/team';
import PayloadPage from './pages/payload';
import ProgressPage from './pages/progress';
import DesignPage from './pages/design';
import FlightPage from './pages/flight';
import ResultsPage from './pages/results';
import ProdNotFoundPage from './pages/_404';

// Routes currently published at https://gccazascendspacerangers.com/
export const routes: RouteObject[] = [
  { path: '/', element: <HomePage /> },
  { path: '/team', element: <TeamPage /> },
  { path: '/payload', element: <PayloadPage /> },
  { path: '/progress', element: <ProgressPage /> },
  { path: '/design', element: <DesignPage /> },
  { path: '/flight', element: <FlightPage /> },
  { path: '/results', element: <ResultsPage /> },
  { path: '*', element: <ProdNotFoundPage /> },
];

export type Path = '/' | '/team' | '/payload' | '/progress' | '/design' | '/flight' | '/results';
export type Params = Record<string, string | undefined>;
