import { createContext, type ReactNode } from 'react';
export const JsonLdSiteUrlContext = createContext('');
export function JsonLdSiteUrlProvider({ siteUrl, children }: { siteUrl: string; children: ReactNode }) {
  return <JsonLdSiteUrlContext.Provider value={siteUrl}>{children}</JsonLdSiteUrlContext.Provider>;
}
