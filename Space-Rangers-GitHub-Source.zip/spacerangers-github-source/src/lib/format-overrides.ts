export interface FormatOverrideBundle { [key: string]: unknown }
