export const siteMeta = { name: 'Space Rangers', summary: 'NASA ASCEND student engineering team at Glendale Community College.' };
