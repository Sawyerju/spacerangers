import { useState, type ReactNode } from 'react';
import { Link, NavLink } from 'react-router';
import { Menu, X } from 'lucide-react';

const nav = [
  ['/', 'Home'],
  ['/team', 'Our Team'],
  ['/payload', 'Our Payload'],
  ['/progress', 'Progress'],
  ['/design', 'Design'],
  ['/flight', 'Flight'],
  ['/results', 'Results'],
] as const;

export default function RootLayout({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-[hsl(var(--surface-navy)/0.96)] backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-3.5 lg:px-8">
          <Link to="/" aria-label="Space Rangers home" className="flex items-center gap-3">
            <img
              src="https://gccazascendspacerangers.com/airo-assets/images/logo/horizontal"
              alt="Space Rangers"
              className="h-9 w-auto max-w-[210px] object-contain"
            />
          </Link>

          <nav className="hidden items-center gap-7 md:flex" aria-label="Main navigation">
            {nav.map(([to, label]) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/'}
                className={({ isActive }) =>
                  `text-sm font-semibold transition-colors ${isActive ? 'text-white' : 'text-white/65 hover:text-white'}`
                }
              >
                {label}
              </NavLink>
            ))}
          </nav>

          <button
            className="rounded-md p-2 text-white md:hidden"
            aria-label={open ? 'Close navigation' : 'Open navigation'}
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {open && (
          <nav className="border-t border-white/10 bg-[hsl(var(--surface-navy))] px-6 py-4 md:hidden" aria-label="Mobile navigation">
            <div className="mx-auto flex max-w-7xl flex-col gap-1">
              {nav.map(([to, label]) => (
                <NavLink
                  key={to}
                  to={to}
                  end={to === '/'}
                  onClick={() => setOpen(false)}
                  className={({ isActive }) =>
                    `rounded-md px-3 py-2 text-sm font-semibold ${isActive ? 'bg-white/10 text-white' : 'text-white/70 hover:bg-white/5 hover:text-white'}`
                  }
                >
                  {label}
                </NavLink>
              ))}
            </div>
          </nav>
        )}
      </header>

      {children}

      <footer className="border-t border-white/10 bg-[hsl(var(--surface-navy))] text-white">
        <div className="mx-auto grid max-w-7xl gap-10 px-6 py-14 md:grid-cols-[1.5fr_1fr_1fr] lg:px-8">
          <div>
            <img
              src="https://gccazascendspacerangers.com/airo-assets/images/logo/horizontal/light"
              alt="Space Rangers"
              className="h-10 w-auto max-w-[240px] object-contain"
            />
            <p className="mt-5 max-w-md text-sm leading-relaxed text-white/60">
              A NASA ASCEND student engineering team at Glendale Community College, designing and building a scientific payload for high-altitude flight.
            </p>
          </div>

          <div>
            <h2 className="text-sm font-bold">Navigation</h2>
            <div className="mt-4 flex flex-col gap-2.5">
              {nav.map(([to, label]) => (
                <Link key={to} to={to} className="text-sm text-white/60 transition-colors hover:text-white">
                  {label}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-sm font-bold">Program</h2>
            <p className="mt-4 text-sm leading-relaxed text-white/60">
              NASA ASCEND<br />
              Advancing Collaborative Connections for Earth, Space, and the Next Generation of Dreamers
            </p>
            <p className="mt-4 text-sm text-white/60">Glendale Community College<br />Glendale, Arizona</p>
          </div>
        </div>
        <div className="border-t border-white/10">
          <div className="mx-auto flex max-w-7xl flex-col gap-2 px-6 py-5 text-xs text-white/45 sm:flex-row sm:items-center sm:justify-between lg:px-8">
            <p>© 2026 Space Rangers — GCC NASA ASCEND Team</p>
            <p>From Design to Flight</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
