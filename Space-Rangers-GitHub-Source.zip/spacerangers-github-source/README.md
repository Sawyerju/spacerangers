# Space Rangers — GitHub-ready Airo reconstruction

This repository is a portable reconstruction of the published Space Rangers NASA ASCEND website:

**https://gccazascendspacerangers.com/**

It combines the React/TypeScript files extracted from GoDaddy Airo with reconstructed build files, layout code, styles, and the published site content so the project can be developed outside Airo.

## Public routes matched to the live site

- `/` — Home
- `/team` — Our Team
- `/payload` — Our Payload
- `/progress` — Progress
- `/design` — Design
- `/flight` — Flight
- `/results` — Results

The homepage's **Our Project** and **View Full Timeline** controls are section anchors (`#project` and `#timeline`), matching the currently published site.

## What came from the Airo extraction

The extracted source supplied the core React application and page components, including:

- `App.tsx`
- `main.tsx`
- `routes.tsx` / router helpers
- Home, Team, Payload, Progress, Design, Flight, Results page components
- additional unpublished Project, Timeline, and Contact page components
- SSR entry files and Airo environment typings

Exact uploaded copies are retained in `original-airo-source/`.

## What was reconstructed

Airo-specific pieces that were not included in the extracted source were replaced with portable equivalents:

- `virtual:content` → `src/content.ts`
- `layouts/RootLayout.tsx`
- Tailwind/Vite/TypeScript configuration
- loading/error/cookie-boundary shims
- package metadata and Vercel SPA rewrite

The main `src/content.ts` content has been rebuilt from the currently published site rather than placeholder copy.

## Images

The original image binaries were not present in the extracted source. For fidelity, the runnable source currently references your existing public Airo image endpoints at:

`https://gccazascendspacerangers.com/airo-assets/...`

That means the site will look much closer to the published version immediately, but it still depends on those image URLs. For a completely independent repository, export/download the image files and replace the absolute URLs with local files in `public/airo-assets/`.

## Run locally

```bash
npm install
npm run dev
```

Vite will print the local development URL, normally `http://localhost:5173`.

## Production build

```bash
npm run build
npm run preview
```

## Hosting

`vercel.json` contains a catch-all rewrite so React Router routes work when deployed to Vercel.

If you deploy with a different host, configure SPA fallback so `/team`, `/payload`, etc. serve `index.html` rather than returning a server-side 404.

## Important remaining dependency

The extracted `contact.tsx` page posts to Airo's `/api/contact/contact-us` endpoint. That page is **not currently routed on the published site**, so it is retained as source only. If you later publish it independently, replace the endpoint with your own backend/serverless form handler.

## Validation

The reconstructed TS/TSX source was syntax-checked locally. A full dependency build requires running `npm install` in an environment with npm network access.
